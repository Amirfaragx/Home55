"use client"

import * as React from "react"
import Link from "next/link"

export function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-8 md:py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div>
            <Link href="/" className="flex items-center space-x-2">
              <span className="font-bold text-xl">ElectroServe</span>
            </Link>
            <p className="mt-2 text-sm text-muted-foreground">
              Your one-stop shop for all electronic services. Quality service delivery is our priority.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-4">
            <div className="font-medium">Services</div>
            <nav className="flex flex-col gap-2">
              <Link href="/services/web-development" className="text-sm text-muted-foreground hover:text-foreground">
                Web Development
              </Link>
              <Link href="/services/app-development" className="text-sm text-muted-foreground hover:text-foreground">
                App Development
              </Link>
              <Link href="/services/it-consulting" className="text-sm text-muted-foreground hover:text-foreground">
                IT Consulting
              </Link>
              <Link href="/services/cloud-services" className="text-sm text-muted-foreground hover:text-foreground">
                Cloud Services
              </Link>
            </nav>
          </div>
          <div className="grid grid-cols-1 gap-4">
            <div className="font-medium">Company</div>
            <nav className="flex flex-col gap-2">
              <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
                About Us
              </Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">
                Contact
              </Link>
              <Link href="/careers" className="text-sm text-muted-foreground hover:text-foreground">
                Careers
              </Link>
              <Link href="/blog" className="text-sm text-muted-foreground hover:text-foreground">
                Blog
              </Link>
            </nav>
          </div>
          <div className="grid grid-cols-1 gap-4">
            <div className="font-medium">Legal</div>
            <nav className="flex flex-col gap-2">
              <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">
                Terms of Service
              </Link>
              <Link href="/cookies" className="text-sm text-muted-foreground hover:text-foreground">
                Cookie Policy
              </Link>
            </nav>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} ElectroServe. All rights reserved.
        </div>
      </div>
    </footer>
  )
}
