"use client"

import React, { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { searchServices } from "@/app/services"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

export function SearchBar() {
  const [query, setQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const router = useRouter()

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!query.trim()) {
      toast.error("Please enter a search term")
      return
    }
    
    setIsSearching(true)
    router.push(`/search?q=${encodeURIComponent(query.trim())}`)
    setIsSearching(false)
  }

  return (
    <Card className="shadow-none border-none">
      <CardContent className="p-0">
        <form onSubmit={handleSearch} className="flex w-full max-w-lg items-center space-x-2">
          <Input
            type="text"
            placeholder="Search for services..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1"
          />
          <Button type="submit" disabled={isSearching}>
            {isSearching ? "Searching..." : "Search"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
