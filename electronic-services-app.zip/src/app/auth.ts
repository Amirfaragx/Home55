"use server"

import { getCloudflareContext } from '@opennextjs/cloudflare'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import crypto from 'crypto'

// Function to hash passwords
function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex')
}

// Function to generate a random token
function generateToken(): string {
  return crypto.randomBytes(32).toString('hex')
}

// Register a new user
export async function registerUser(formData: {
  username: string
  email: string
  password: string
}) {
  const cf = await getCloudflareContext()
  
  try {
    // Check if user already exists
    const { results: existingUsers } = await cf.env.DB.prepare(
      'SELECT id FROM users WHERE email = ? OR username = ?'
    )
      .bind(formData.email, formData.username)
      .all()
    
    if (existingUsers.length > 0) {
      return { success: false, message: 'User with this email or username already exists' }
    }
    
    // Hash the password
    const passwordHash = hashPassword(formData.password)
    
    // Insert the new user
    const { results } = await cf.env.DB.prepare(
      'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?) RETURNING id'
    )
      .bind(formData.username, formData.email, passwordHash)
      .all()
    
    if (!results || results.length === 0) {
      return { success: false, message: 'Failed to create user' }
    }
    
    const userId = results[0].id
    
    // Create empty profile for the user
    await cf.env.DB.prepare(
      'INSERT INTO user_profiles (user_id) VALUES (?)'
    )
      .bind(userId)
      .run()
    
    // Generate session token
    const sessionToken = generateToken()
    const expiresAt = new Date()
    expiresAt.setDate(expiresAt.getDate() + 7) // Token expires in 7 days
    
    // Store session
    await cf.env.DB.prepare(
      'INSERT INTO sessions (user_id, session_token, expires_at) VALUES (?, ?, ?)'
    )
      .bind(userId, sessionToken, expiresAt.toISOString())
      .run()
    
    // Set session cookie
    cookies().set({
      name: 'session_token',
      value: sessionToken,
      httpOnly: true,
      path: '/',
      expires: expiresAt,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax'
    })
    
    return { success: true, userId }
  } catch (error) {
    console.error('Registration error:', error)
    return { success: false, message: 'An error occurred during registration' }
  }
}

// Login user
export async function loginUser(formData: {
  email: string
  password: string
}) {
  const cf = await getCloudflareContext()
  
  try {
    // Get user with matching email
    const { results: users } = await cf.env.DB.prepare(
      'SELECT id, password_hash FROM users WHERE email = ?'
    )
      .bind(formData.email)
      .all()
    
    if (!users || users.length === 0) {
      return { success: false, message: 'Invalid email or password' }
    }
    
    const user = users[0]
    
    // Check password
    const passwordHash = hashPassword(formData.password)
    if (passwordHash !== user.password_hash) {
      return { success: false, message: 'Invalid email or password' }
    }
    
    // Generate session token
    const sessionToken = generateToken()
    const expiresAt = new Date()
    expiresAt.setDate(expiresAt.getDate() + 7) // Token expires in 7 days
    
    // Store session
    await cf.env.DB.prepare(
      'INSERT INTO sessions (user_id, session_token, expires_at) VALUES (?, ?, ?)'
    )
      .bind(user.id, sessionToken, expiresAt.toISOString())
      .run()
    
    // Set session cookie
    cookies().set({
      name: 'session_token',
      value: sessionToken,
      httpOnly: true,
      path: '/',
      expires: expiresAt,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax'
    })
    
    return { success: true, userId: user.id }
  } catch (error) {
    console.error('Login error:', error)
    return { success: false, message: 'An error occurred during login' }
  }
}

// Logout user
export async function logoutUser() {
  const cf = await getCloudflareContext()
  const sessionToken = cookies().get('session_token')?.value
  
  if (sessionToken) {
    // Delete session from database
    await cf.env.DB.prepare(
      'DELETE FROM sessions WHERE session_token = ?'
    )
      .bind(sessionToken)
      .run()
    
    // Clear cookie
    cookies().delete('session_token')
  }
  
  redirect('/')
}

// Get current user
export async function getCurrentUser() {
  const cf = await getCloudflareContext()
  const sessionToken = cookies().get('session_token')?.value
  
  if (!sessionToken) {
    return null
  }
  
  try {
    // Get session with valid expiration
    const { results: sessions } = await cf.env.DB.prepare(
      'SELECT user_id FROM sessions WHERE session_token = ? AND expires_at > datetime()'
    )
      .bind(sessionToken)
      .all()
    
    if (!sessions || sessions.length === 0) {
      cookies().delete('session_token')
      return null
    }
    
    const userId = sessions[0].user_id
    
    // Get user data
    const { results: users } = await cf.env.DB.prepare(
      'SELECT id, username, email FROM users WHERE id = ?'
    )
      .bind(userId)
      .all()
    
    if (!users || users.length === 0) {
      cookies().delete('session_token')
      return null
    }
    
    return users[0]
  } catch (error) {
    console.error('Get current user error:', error)
    return null
  }
}
