"use client"

import React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { searchServices } from "@/app/services"
import { SearchBar } from "@/components/search-bar"

interface SearchPageProps {
  searchParams: { q: string }
}

export default async function SearchPage({ searchParams }: SearchPageProps) {
  const query = searchParams.q || ""
  const { success, services, message } = await searchServices(query)
  
  return (
    <div className="container py-10">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl mb-4">Search Results</h1>
        <p className="text-muted-foreground max-w-[800px] mb-8">
          Showing results for "{query}"
        </p>
        <div className="w-full max-w-lg mb-8">
          <SearchBar />
        </div>
      </div>

      {!success ? (
        <div className="text-center py-10">
          <p className="text-muted-foreground">{message || "Failed to load search results. Please try again later."}</p>
        </div>
      ) : services.length === 0 ? (
        <div className="text-center py-10">
          <p className="text-muted-foreground">No services found matching your search criteria.</p>
          <Link href="/services">
            <Button className="mt-4">Browse All Services</Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <Card key={service.id} className="flex flex-col h-full">
              <CardContent className="p-6 flex flex-col h-full">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold">{service.name}</h3>
                    <Link href={`/services/${service.category_slug}`}>
                      <Badge variant="outline" className="mt-2">{service.category_name}</Badge>
                    </Link>
                  </div>
                  {service.featured && (
                    <Badge>Featured</Badge>
                  )}
                </div>
                
                <p className="text-muted-foreground mb-4 flex-grow">{service.short_description}</p>
                
                <div className="mt-auto">
                  <div className="flex items-center mb-4">
                    {service.discount_price ? (
                      <>
                        <span className="text-2xl font-bold">${service.discount_price.toFixed(2)}</span>
                        <span className="text-muted-foreground line-through ml-2">${service.price.toFixed(2)}</span>
                      </>
                    ) : (
                      <span className="text-2xl font-bold">${service.price.toFixed(2)}</span>
                    )}
                  </div>
                  
                  <Link href={`/services/${service.category_slug}/${service.slug}`} className="w-full">
                    <Button className="w-full">View Details</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
