"use client"

import React from "react"
import { getServiceBySlug } from "@/app/services"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Check, Star } from "lucide-react"
import { Separator } from "@/components/ui/separator"
import { getCurrentUser } from "@/app/auth"
import { orderServiceAction } from "./actions"

interface ServiceDetailPageProps {
  params: {
    slug: string
    serviceSlug: string
  }
}

export default async function ServiceDetailPage({ params }: ServiceDetailPageProps) {
  const { slug, serviceSlug } = params
  const { success, service, message } = await getServiceBySlug(serviceSlug)
  const currentUser = await getCurrentUser()
  
  if (!success) {
    return (
      <div className="container py-10">
        <div className="text-center py-10">
          <p className="text-muted-foreground">{message || "Service not found"}</p>
          <Link href="/services">
            <Button className="mt-4">Back to Services</Button>
          </Link>
        </div>
      </div>
    )
  }
  
  return (
    <div className="container py-10">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="flex items-center mb-2">
            <Link href="/services">
              <span className="text-sm text-muted-foreground hover:underline">Services</span>
            </Link>
            <span className="mx-2 text-muted-foreground">/</span>
            <Link href={`/services/${slug}`}>
              <span className="text-sm text-muted-foreground hover:underline">{service.category_name}</span>
            </Link>
          </div>
          
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl mb-4">{service.name}</h1>
          
          <div className="flex items-center mb-6">
            {service.featured && (
              <Badge className="mr-2">Featured</Badge>
            )}
            <div className="flex items-center">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`h-4 w-4 ${
                    star <= Math.round(service.avgRating)
                      ? "fill-primary text-primary"
                      : "text-muted-foreground"
                  }`}
                />
              ))}
              <span className="ml-2 text-sm text-muted-foreground">
                {service.avgRating.toFixed(1)} ({service.reviews.length} reviews)
              </span>
            </div>
          </div>
          
          <div className="prose dark:prose-invert max-w-none mb-8">
            <p className="text-lg mb-4">{service.short_description}</p>
            <p>{service.description}</p>
          </div>
          
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4">Features</h2>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {service.features.map((feature, index) => (
                <li key={index} className="flex items-center">
                  <Check className="h-5 w-5 text-primary mr-2" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <Separator className="my-8" />
          
          <div>
            <h2 className="text-xl font-bold mb-4">Customer Reviews</h2>
            {service.reviews.length === 0 ? (
              <p className="text-muted-foreground">No reviews yet. Be the first to review this service!</p>
            ) : (
              <div className="space-y-6">
                {service.reviews.map((review) => (
                  <Card key={review.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-base">{review.username}</CardTitle>
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-4 w-4 ${
                                star <= review.rating
                                  ? "fill-primary text-primary"
                                  : "text-muted-foreground"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <CardDescription>
                        {new Date(review.created_at).toLocaleDateString()}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p>{review.comment}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
        
        <div>
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle>Service Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium mb-1">Price</h3>
                  <div className="flex items-center">
                    {service.discount_price ? (
                      <>
                        <span className="text-3xl font-bold">${service.discount_price.toFixed(2)}</span>
                        <span className="text-muted-foreground line-through ml-2">${service.price.toFixed(2)}</span>
                      </>
                    ) : (
                      <span className="text-3xl font-bold">${service.price.toFixed(2)}</span>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-1">Category</h3>
                  <p>{service.category_name}</p>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <form action={() => orderServiceAction(service.id, slug, serviceSlug)}>
                    <Button className="w-full" size="lg">
                      Order Now
                    </Button>
                  </form>
                  
                  {!currentUser && (
                    <p className="text-xs text-muted-foreground text-center">
                      You need to{" "}
                      <Link href={`/login?redirect=/services/${slug}/${serviceSlug}`} className="underline">
                        login
                      </Link>{" "}
                      to order this service
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
