"use server"

import { getCurrentUser } from "@/app/auth"
import { createServiceOrder } from "@/app/services"
import { redirect } from "next/navigation"

export async function orderServiceAction(serviceId: number, slug: string, serviceSlug: string) {
  const user = await getCurrentUser()
  if (!user) {
    return redirect('/login?redirect=/services/' + slug + '/' + serviceSlug)
  }
  
  const result = await createServiceOrder(user.id, serviceId)
  if (result.success) {
    return redirect('/dashboard?tab=services&ordered=' + serviceId)
  } else {
    return redirect('/services/' + slug + '/' + serviceSlug + '?error=order-failed')
  }
}
