"use client"

import React from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { getFeaturedServices } from "@/app/services"

export default async function ServicesPage() {
  const { success, services, message } = await getFeaturedServices(10)
  
  return (
    <div className="container py-10">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl mb-4">Our Electronic Services</h1>
        <p className="text-muted-foreground max-w-[800px] mb-8">
          Browse our comprehensive range of electronic services designed to meet your needs. From web development to cloud services, we have you covered.
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          <Link href="/services/web-development">
            <Badge variant="outline" className="px-4 py-2 text-sm cursor-pointer hover:bg-accent">Web Development</Badge>
          </Link>
          <Link href="/services/app-development">
            <Badge variant="outline" className="px-4 py-2 text-sm cursor-pointer hover:bg-accent">App Development</Badge>
          </Link>
          <Link href="/services/it-consulting">
            <Badge variant="outline" className="px-4 py-2 text-sm cursor-pointer hover:bg-accent">IT Consulting</Badge>
          </Link>
          <Link href="/services/cloud-services">
            <Badge variant="outline" className="px-4 py-2 text-sm cursor-pointer hover:bg-accent">Cloud Services</Badge>
          </Link>
        </div>
      </div>

      {!success ? (
        <div className="text-center py-10">
          <p className="text-muted-foreground">{message || "Failed to load services. Please try again later."}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <Card key={service.id} className="flex flex-col h-full">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl">{service.name}</CardTitle>
                    <CardDescription className="mt-2">{service.category_name}</CardDescription>
                  </div>
                  {service.featured && (
                    <Badge className="ml-2">Featured</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-muted-foreground mb-4">{service.short_description}</p>
                <div className="flex items-center mt-4">
                  {service.discount_price ? (
                    <>
                      <span className="text-2xl font-bold">${service.discount_price.toFixed(2)}</span>
                      <span className="text-muted-foreground line-through ml-2">${service.price.toFixed(2)}</span>
                    </>
                  ) : (
                    <span className="text-2xl font-bold">${service.price.toFixed(2)}</span>
                  )}
                </div>
              </CardContent>
              <CardFooter>
                <Link href={`/services/${service.category_slug}/${service.slug}`} className="w-full">
                  <Button className="w-full">View Details</Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
