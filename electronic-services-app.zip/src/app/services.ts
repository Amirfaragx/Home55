"use server"

import { getCloudflareContext } from '@opennextjs/cloudflare'

// Get all service categories
export async function getServiceCategories() {
  const cf = await getCloudflareContext()
  
  try {
    const { results } = await cf.env.DB.prepare(
      'SELECT * FROM service_categories ORDER BY name'
    ).all()
    
    return { success: true, categories: results }
  } catch (error) {
    console.error('Error fetching service categories:', error)
    return { success: false, message: 'Failed to fetch service categories' }
  }
}

// Get services by category
export async function getServicesByCategory(categorySlug: string) {
  const cf = await getCloudflareContext()
  
  try {
    const { results } = await cf.env.DB.prepare(
      `SELECT s.* 
       FROM services s
       JOIN service_categories c ON s.category_id = c.id
       WHERE c.slug = ? AND s.is_active = 1
       ORDER BY s.name`
    )
      .bind(categorySlug)
      .all()
    
    return { success: true, services: results }
  } catch (error) {
    console.error('Error fetching services by category:', error)
    return { success: false, message: 'Failed to fetch services' }
  }
}

// Get featured services
export async function getFeaturedServices(limit = 6) {
  const cf = await getCloudflareContext()
  
  try {
    const { results } = await cf.env.DB.prepare(
      `SELECT s.*, c.name as category_name, c.slug as category_slug
       FROM services s
       JOIN service_categories c ON s.category_id = c.id
       WHERE s.featured = 1 AND s.is_active = 1
       ORDER BY s.created_at DESC
       LIMIT ?`
    )
      .bind(limit)
      .all()
    
    return { success: true, services: results }
  } catch (error) {
    console.error('Error fetching featured services:', error)
    return { success: false, message: 'Failed to fetch featured services' }
  }
}

// Get service details by slug
export async function getServiceBySlug(slug: string) {
  const cf = await getCloudflareContext()
  
  try {
    // Get service details
    const { results: services } = await cf.env.DB.prepare(
      `SELECT s.*, c.name as category_name, c.slug as category_slug
       FROM services s
       JOIN service_categories c ON s.category_id = c.id
       WHERE s.slug = ? AND s.is_active = 1`
    )
      .bind(slug)
      .all()
    
    if (!services || services.length === 0) {
      return { success: false, message: 'Service not found' }
    }
    
    const service = services[0]
    
    // Get service features
    const { results: features } = await cf.env.DB.prepare(
      'SELECT feature FROM service_features WHERE service_id = ?'
    )
      .bind(service.id)
      .all()
    
    // Get service reviews
    const { results: reviews } = await cf.env.DB.prepare(
      `SELECT r.*, u.username 
       FROM service_reviews r
       JOIN users u ON r.user_id = u.id
       WHERE r.service_id = ?
       ORDER BY r.created_at DESC`
    )
      .bind(service.id)
      .all()
    
    // Calculate average rating
    let avgRating = 0
    if (reviews.length > 0) {
      const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0)
      avgRating = totalRating / reviews.length
    }
    
    return { 
      success: true, 
      service: {
        ...service,
        features: features.map(f => f.feature),
        reviews,
        avgRating
      }
    }
  } catch (error) {
    console.error('Error fetching service details:', error)
    return { success: false, message: 'Failed to fetch service details' }
  }
}

// Search services
export async function searchServices(query: string) {
  const cf = await getCloudflareContext()
  
  try {
    const searchTerm = `%${query}%`
    
    const { results } = await cf.env.DB.prepare(
      `SELECT s.*, c.name as category_name, c.slug as category_slug
       FROM services s
       JOIN service_categories c ON s.category_id = c.id
       WHERE (s.name LIKE ? OR s.description LIKE ? OR s.short_description LIKE ?)
       AND s.is_active = 1
       ORDER BY s.featured DESC, s.name`
    )
      .bind(searchTerm, searchTerm, searchTerm)
      .all()
    
    return { success: true, services: results }
  } catch (error) {
    console.error('Error searching services:', error)
    return { success: false, message: 'Failed to search services' }
  }
}

// Create service order
export async function createServiceOrder(userId: number, serviceId: number) {
  const cf = await getCloudflareContext()
  
  try {
    // Get service price
    const { results: services } = await cf.env.DB.prepare(
      'SELECT price, discount_price FROM services WHERE id = ? AND is_active = 1'
    )
      .bind(serviceId)
      .all()
    
    if (!services || services.length === 0) {
      return { success: false, message: 'Service not found or inactive' }
    }
    
    const service = services[0]
    const price = service.discount_price || service.price
    
    // Create order
    const { results } = await cf.env.DB.prepare(
      'INSERT INTO service_orders (user_id, service_id, total_price) VALUES (?, ?, ?) RETURNING id'
    )
      .bind(userId, serviceId, price)
      .all()
    
    if (!results || results.length === 0) {
      return { success: false, message: 'Failed to create order' }
    }
    
    return { success: true, orderId: results[0].id }
  } catch (error) {
    console.error('Error creating service order:', error)
    return { success: false, message: 'Failed to create service order' }
  }
}
