-- Migration number: 0003 	 2025-04-02T15:37:30.000Z
-- Electronic services catalog tables

-- Create service categories table
CREATE TABLE IF NOT EXISTS service_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  icon TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create services table
CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT NOT NULL,
  short_description TEXT,
  price REAL NOT NULL,
  discount_price REAL,
  image TEXT,
  featured BOOLEAN DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES service_categories(id) ON DELETE CASCADE
);

-- Create service features table
CREATE TABLE IF NOT EXISTS service_features (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_id INTEGER NOT NULL,
  feature TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
);

-- Create service reviews table
CREATE TABLE IF NOT EXISTS service_reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create service orders table
CREATE TABLE IF NOT EXISTS service_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  service_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  total_price REAL NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
);

-- Insert initial service categories
INSERT INTO service_categories (name, slug, description, icon) VALUES 
  ('Web Development', 'web-development', 'Custom website development and maintenance services for businesses and individuals.', 'layout'),
  ('App Development', 'app-development', 'Mobile application development for iOS and Android platforms.', 'smartphone'),
  ('IT Consulting', 'it-consulting', 'Expert advice on technology implementation and digital transformation.', 'lightbulb'),
  ('Cloud Services', 'cloud-services', 'Cloud infrastructure setup, migration, and management services.', 'cloud');

-- Insert sample services
INSERT INTO services (category_id, name, slug, description, short_description, price, discount_price, featured, is_active) VALUES
  (1, 'Basic Website', 'basic-website', 'A simple yet professional website with up to 5 pages. Perfect for small businesses and personal portfolios.', 'Simple 5-page website for small businesses', 499.99, 449.99, 1, 1),
  (1, 'E-commerce Website', 'ecommerce-website', 'A full-featured online store with product catalog, shopping cart, and payment processing.', 'Complete online store solution', 1499.99, 1299.99, 1, 1),
  (1, 'Custom Web Application', 'custom-web-application', 'Tailor-made web applications designed to meet your specific business needs and workflows.', 'Tailor-made web applications', 2999.99, NULL, 0, 1),
  (2, 'iOS App Development', 'ios-app-development', 'Native iOS application development for iPhone and iPad with App Store submission.', 'Native iPhone and iPad apps', 3999.99, 3499.99, 1, 1),
  (2, 'Android App Development', 'android-app-development', 'Native Android application development with Google Play Store submission.', 'Native Android applications', 3499.99, 2999.99, 0, 1),
  (2, 'Cross-platform App', 'cross-platform-app', 'Develop once, deploy everywhere. Apps that work on both iOS and Android platforms.', 'Apps for both iOS and Android', 4999.99, 4499.99, 1, 1),
  (3, 'IT Strategy Consultation', 'it-strategy-consultation', 'Comprehensive analysis and strategic planning for your organization\'s technology needs.', 'Strategic technology planning', 999.99, NULL, 0, 1),
  (3, 'Digital Transformation', 'digital-transformation', 'Guide your business through digital transformation with expert consulting and implementation.', 'Business technology modernization', 2499.99, 1999.99, 1, 1),
  (4, 'Cloud Migration', 'cloud-migration', 'Seamlessly migrate your existing infrastructure and applications to the cloud.', 'Move to the cloud seamlessly', 1999.99, 1799.99, 1, 1),
  (4, 'Cloud Infrastructure Setup', 'cloud-infrastructure-setup', 'Design and implement a scalable, secure cloud infrastructure tailored to your needs.', 'Custom cloud infrastructure', 2999.99, NULL, 0, 1);

-- Insert sample service features
INSERT INTO service_features (service_id, feature) VALUES
  (1, 'Up to 5 pages'),
  (1, 'Mobile responsive design'),
  (1, 'Contact form'),
  (1, 'Basic SEO optimization'),
  (1, '1 month of support'),
  (2, 'Product catalog with unlimited items'),
  (2, 'Secure payment processing'),
  (2, 'Customer account management'),
  (2, 'Order tracking system'),
  (2, 'Inventory management'),
  (2, '3 months of support'),
  (3, 'Custom functionality'),
  (3, 'Database design and implementation'),
  (3, 'API integrations'),
  (3, 'User authentication system'),
  (3, '6 months of support'),
  (4, 'Native iOS development'),
  (4, 'UI/UX design'),
  (4, 'App Store submission'),
  (4, 'Push notifications'),
  (4, '3 months of support'),
  (5, 'Native Android development'),
  (5, 'Material Design implementation'),
  (5, 'Google Play Store submission'),
  (5, 'Firebase integration'),
  (5, '3 months of support'),
  (6, 'Single codebase for iOS and Android'),
  (6, 'Native-like performance'),
  (6, 'Shared UI across platforms'),
  (6, 'App Store and Play Store submission'),
  (6, '6 months of support'),
  (7, 'Technology assessment'),
  (7, 'Strategic roadmap development'),
  (7, 'Budget planning'),
  (7, 'Vendor selection assistance'),
  (7, 'Implementation guidance'),
  (8, 'Business process analysis'),
  (8, 'Technology stack modernization'),
  (8, 'Staff training'),
  (8, 'Change management'),
  (8, 'Ongoing support'),
  (9, 'Assessment of current infrastructure'),
  (9, 'Migration planning'),
  (9, 'Data transfer'),
  (9, 'Testing and validation'),
  (9, 'Post-migration support'),
  (10, 'Cloud architecture design'),
  (10, 'Security implementation'),
  (10, 'Scalability planning'),
  (10, 'Monitoring setup'),
  (10, 'Documentation and training');

-- Create indexes
CREATE INDEX idx_services_category_id ON services(category_id);
CREATE INDEX idx_services_featured ON services(featured);
CREATE INDEX idx_services_is_active ON services(is_active);
CREATE INDEX idx_service_features_service_id ON service_features(service_id);
CREATE INDEX idx_service_reviews_service_id ON service_reviews(service_id);
CREATE INDEX idx_service_reviews_user_id ON service_reviews(user_id);
CREATE INDEX idx_service_orders_user_id ON service_orders(user_id);
CREATE INDEX idx_service_orders_service_id ON service_orders(service_id);
CREATE INDEX idx_service_orders_status ON service_orders(status);
